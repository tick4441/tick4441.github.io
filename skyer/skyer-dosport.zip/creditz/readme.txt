Hello! Thank you for checking out a game that is only for the BRAVE....

Skyer is a single player, adventure, building and survival game where you explore an infinite 2d platfromer style world with wacky items and enemies, weird weather and a void that surrounds the ground. Do your best to survive this game because dear player, you have just entered a game that learns from you as you play. it changes. it learns. it EVOLVES. How far can you go? this game is always changing.

See license for more info on this game.

Coded by Gemini and Skyer Team.

Art by Skyer Team.

Hope you enjoy this game, player... Good luck to you. Sometimes, This game may give you luck. Do not give up and have patience. that's the key to this game. and who knows, dear player? maybe you'll get far! But don't get too far because the farther you go, the more chaotic it gets...

Find out more by playing! 

To start this game, just open "index.html" in your browser! It must support html5!

have fun! :D
